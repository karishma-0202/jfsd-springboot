package com.example.S27;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController         //this class is used for rest services.input &output is via browser
@RequestMapping("/welcome")
public class welcome {
	
	@GetMapping("/welcome")
	public String welcomepage()
	{
		return "this is a Welcome Page";
	}
	@GetMapping("/home")
	public String homepage()
	{
		return "this is a home Page";
	}
	@GetMapping("/cse")
	public String csepage()
	{
		return "this is a cse Page";
	}
	
}

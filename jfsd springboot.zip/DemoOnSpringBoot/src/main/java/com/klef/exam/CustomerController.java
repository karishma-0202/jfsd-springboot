
package com.klef.exam;

import com.klef.exam.Customer;
import com.klef.exam.CustomerRepository;
import com.klef.exam.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CustomerService customerService;

    // Add a new customer
    @PostMapping
    public Customer addCustomer(@RequestBody Customer customer) {
        return customerRepository.save(customer);
    }

    // Get all customers
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    // Update customer name and address
    @PutMapping("/{id}")
    public Customer updateCustomer(@PathVariable Long id, @RequestParam String name, @RequestParam String address) {
        return customerService.updateCustomer(id, name, address);
    }
}

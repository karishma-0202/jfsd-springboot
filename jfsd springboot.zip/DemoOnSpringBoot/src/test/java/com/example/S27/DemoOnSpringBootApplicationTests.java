package com.example.S27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOnSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
